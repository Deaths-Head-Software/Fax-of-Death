import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class DeathTheme {
  // Death's Head signature colors
  static const Color darkRed = Color(0xFFCC0000);
  static const Color deepRed = Color(0xFFDD2222);
  static const Color bloodRed = Color(0xFFEE0000);
  static const Color black = Color(0xFF0A0A0A);
  static const Color darkGrey = Color(0xFF1A1A1A);
  static const Color midGrey = Color(0xFF2A2A2A);
  static const Color lightGrey = Color(0xFF3A3A3A);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFCCCCCC);
  static const Color textMuted = Color(0xFF888888);
  static const Color success = Color(0xFF00CC44);
  static const Color warning = Color(0xFFFF9900);
  static const Color error = Color(0xFFFF3333);

  /// Base Courier Prime text theme for the entire app.
  static TextTheme get _courierTextTheme =>
      GoogleFonts.courierPrimeTextTheme(ThemeData.dark().textTheme);

  static ThemeData get theme {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: darkRed,
      scaffoldBackgroundColor: black,
      textTheme: _courierTextTheme,
      colorScheme: const ColorScheme.dark(
        primary: darkRed,
        secondary: deepRed,
        surface: darkGrey,
        error: error,
        onPrimary: textPrimary,
        onSecondary: textPrimary,
        onSurface: textPrimary,
        onError: textPrimary,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: darkGrey,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.courierPrime(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: darkRed,
          letterSpacing: 1.5,
        ),
      ),
      cardTheme: CardThemeData(
        color: darkGrey,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: const BorderSide(color: lightGrey, width: 0.5),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: darkRed,
          foregroundColor: textPrimary,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
          ),
          textStyle: GoogleFonts.courierPrime(
            fontWeight: FontWeight.bold,
            letterSpacing: 1.0,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: darkRed,
          side: const BorderSide(color: darkRed),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: midGrey,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6),
          borderSide: const BorderSide(color: lightGrey),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6),
          borderSide: const BorderSide(color: lightGrey),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6),
          borderSide: const BorderSide(color: darkRed, width: 2),
        ),
        labelStyle: const TextStyle(color: textSecondary),
        hintStyle: const TextStyle(color: textMuted),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: darkRed,
        foregroundColor: textPrimary,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: darkGrey,
        selectedItemColor: darkRed,
        unselectedItemColor: textMuted,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: GoogleFonts.courierPrime(fontSize: 11),
        unselectedLabelStyle: GoogleFonts.courierPrime(fontSize: 11),
      ),
      dividerColor: lightGrey,
      iconTheme: const IconThemeData(color: textSecondary),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: midGrey,
        contentTextStyle: GoogleFonts.courierPrime(color: textPrimary),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
