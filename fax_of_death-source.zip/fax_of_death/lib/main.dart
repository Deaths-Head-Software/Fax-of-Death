import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'theme/death_theme.dart';
import 'services/database_service.dart';
import 'services/fax_manager.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize FFI database factory for desktop platforms
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  runApp(const FaxOfDeathApp());
}

class FaxOfDeathApp extends StatelessWidget {
  const FaxOfDeathApp({super.key});

  @override
  Widget build(BuildContext context) {
    final databaseService = DatabaseService();

    return MultiProvider(
      providers: [
        Provider<DatabaseService>.value(value: databaseService),
        ChangeNotifierProvider<FaxManager>(
          create: (_) => FaxManager(databaseService: databaseService),
        ),
      ],
      child: MaterialApp(
        title: 'Fax of Death',
        debugShowCheckedModeBanner: false,
        theme: DeathTheme.theme,
        home: const SplashScreen(),
      ),
    );
  }
}
