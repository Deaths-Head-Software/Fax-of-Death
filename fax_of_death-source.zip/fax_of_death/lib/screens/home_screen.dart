import 'package:flutter/material.dart';
import '../models/fax.dart';
import 'package:provider/provider.dart';
import '../theme/death_theme.dart';
import '../services/fax_manager.dart';
import '../services/database_service.dart';
import 'send_fax_screen.dart';
import 'inbox_screen.dart';
import 'history_screen.dart';
import 'contacts_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final _screens = const [
    _DashboardTab(),
    InboxScreen(),
    HistoryScreen(),
    ContactsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final manager = context.watch<FaxManager>();

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.fax, color: DeathTheme.darkRed, size: 22),
            SizedBox(width: 8),
            Text('FAX OF DEATH'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: DeathTheme.textSecondary),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          if (!manager.isConfigured) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text('Configure your Sinch API credentials first'),
                action: SnackBarAction(
                  label: 'SETTINGS',
                  textColor: DeathTheme.darkRed,
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  ),
                ),
              ),
            );
            return;
          }
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SendFaxScreen()),
          );
        },
        icon: const Icon(Icons.send),
        label: const Text('SEND FAX'),
      ),
      bottomNavigationBar: Consumer<FaxManager>(
        builder: (context, manager, _) {
          return BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() => _currentIndex = index);
              // Clear unread badge when switching to inbox
              if (index == 1) {
                context.read<FaxManager>().clearUnread();
              }
            },
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.dashboard),
                label: 'DASHBOARD',
              ),
              BottomNavigationBarItem(
                icon: Badge(
                  isLabelVisible: manager.unreadCount > 0,
                  label: Text('${manager.unreadCount}'),
                  backgroundColor: DeathTheme.darkRed,
                  child: const Icon(Icons.inbox),
                ),
                label: 'INBOX',
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.history),
                label: 'HISTORY',
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.contacts),
                label: 'CONTACTS',
              ),
            ],
          );
        },
      ),
    );
  }
}

class _DashboardTab extends StatelessWidget {
  const _DashboardTab();

  @override
  Widget build(BuildContext context) {
    final manager = context.read<FaxManager>();

    if (!manager.isConfigured) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.settings_outlined,
                size: 64,
                color: DeathTheme.textMuted,
              ),
              const SizedBox(height: 16),
              const Text(
                'SETUP REQUIRED',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: DeathTheme.darkRed,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Enter your Sinch project ID and '
                'access key to get started.',
                textAlign: TextAlign.center,
                style: TextStyle(color: DeathTheme.textSecondary),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                ),
                icon: const Icon(Icons.settings),
                label: const Text('OPEN SETTINGS'),
              ),
            ],
          ),
        ),
      );
    }

    return Consumer<FaxManager>(
      builder: (context, manager, _) {
        final faxes = manager.recentFaxes;
        final sent = faxes
            .where((f) => f.direction == FaxDirection.outbound)
            .length;
        final received = faxes
            .where((f) => f.direction == FaxDirection.inbound)
            .length;
        final pending = faxes
            .where((f) => !f.isComplete)
            .length;

        return RefreshIndicator(
          color: DeathTheme.darkRed,
          onRefresh: () => manager.loadFaxes(),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Stats row
              Row(
                children: [
                  _StatCard(
                    label: 'SENT',
                    value: '$sent',
                    icon: Icons.call_made,
                    color: DeathTheme.success,
                  ),
                  const SizedBox(width: 12),
                  _StatCard(
                    label: 'RECEIVED',
                    value: '$received',
                    icon: Icons.call_received,
                    color: DeathTheme.deepRed,
                  ),
                  const SizedBox(width: 12),
                  _StatCard(
                    label: 'PENDING',
                    value: '$pending',
                    icon: Icons.hourglass_empty,
                    color: DeathTheme.warning,
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Fax number display
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const Icon(Icons.phone, color: DeathTheme.darkRed),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'YOUR FAX NUMBER',
                            style: TextStyle(
                              fontSize: 10,
                              color: DeathTheme.textMuted,
                              letterSpacing: 1.5,
                            ),
                          ),
                          Text(
                            manager.faxNumber,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: DeathTheme.textPrimary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Recent activity
              const Text(
                'RECENT ACTIVITY',
                style: TextStyle(
                  fontSize: 12,
                  color: DeathTheme.textMuted,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 8),

              if (faxes.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(
                      child: Text(
                        'No faxes yet.\nTap SEND FAX to get started.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: DeathTheme.textMuted),
                      ),
                    ),
                  ),
                )
              else
                ...faxes.take(10).map((fax) => _FaxListTile(fax: fax)),
            ],
          ),
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 8),
              Text(
                value,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 9,
                  color: DeathTheme.textMuted,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FaxListTile extends StatelessWidget {
  final Fax fax;
  const _FaxListTile({required this.fax});

  @override
  Widget build(BuildContext context) {
    final isInbound = fax.direction == FaxDirection.inbound;
    final statusColor = switch (fax.status) {
      FaxStatus.delivered || FaxStatus.received => DeathTheme.success,
      FaxStatus.failed => DeathTheme.error,
      FaxStatus.queued || FaxStatus.sending || FaxStatus.receiving =>
        DeathTheme.warning,
      FaxStatus.cancelled => DeathTheme.textMuted,
    };

    return Dismissible(
      key: ValueKey(fax.id ?? fax.telnyxId),
      direction: DismissDirection.endToStart,
      background: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: DeathTheme.error,
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async {
        return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: DeathTheme.darkGrey,
            title: const Text('DELETE FAX',
                style: TextStyle(color: DeathTheme.darkRed)),
            content: const Text('Delete this fax?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('CANCEL',
                    style: TextStyle(color: DeathTheme.textMuted)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: DeathTheme.error),
                onPressed: () => Navigator.pop(context, true),
                child: const Text('DELETE'),
              ),
            ],
          ),
        );
      },
      onDismissed: (_) async {
        if (fax.id != null) {
          final db = context.read<DatabaseService>();
          await db.deleteFax(fax.id!);
          context.read<FaxManager>().loadFaxes();
        }
      },
      child: Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: Icon(
            isInbound ? Icons.call_received : Icons.call_made,
            color: isInbound ? DeathTheme.deepRed : DeathTheme.textSecondary,
          ),
          title: Text(
            fax.contactName ?? (isInbound ? fax.fromNumber : fax.toNumber),
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: DeathTheme.textPrimary,
            ),
          ),
          subtitle: Text(
            '${isInbound ? "From" : "To"}: ${isInbound ? fax.fromNumber : fax.toNumber}',
            style: const TextStyle(fontSize: 12, color: DeathTheme.textSecondary),
          ),
          trailing: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                fax.statusDisplay,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                  letterSpacing: 1.0,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatTime(fax.createdAt),
                style: const TextStyle(
                  fontSize: 10,
                  color: DeathTheme.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${dt.month}/${dt.day}/${dt.year}';
  }
}

