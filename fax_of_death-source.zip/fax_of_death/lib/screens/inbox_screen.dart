import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:open_file/open_file.dart';
import '../theme/death_theme.dart';
import '../models/fax.dart';
import '../services/fax_manager.dart';
import '../services/database_service.dart';

class InboxScreen extends StatefulWidget {
  const InboxScreen({super.key});

  @override
  State<InboxScreen> createState() => _InboxScreenState();
}

class _InboxScreenState extends State<InboxScreen> {
  final Set<int> _selected = {};
  bool _selectMode = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FaxManager>()
        ..loadFaxes()
        ..clearUnread();
    });
  }

  void _toggleSelect(int id) {
    setState(() {
      if (_selected.contains(id)) {
        _selected.remove(id);
        if (_selected.isEmpty) _selectMode = false;
      } else {
        _selected.add(id);
      }
    });
  }

  void _selectAll(List<Fax> faxes) {
    setState(() {
      _selected.addAll(faxes.where((f) => f.id != null).map((f) => f.id!));
    });
  }

  Future<void> _deleteSelected() async {
    if (_selected.isEmpty) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: DeathTheme.darkGrey,
        title: const Text('DELETE FAXES',
            style: TextStyle(color: DeathTheme.darkRed)),
        content: Text('Delete ${_selected.length} fax${_selected.length > 1 ? "es" : ""}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL',
                style: TextStyle(color: DeathTheme.textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: DeathTheme.error),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final db = context.read<DatabaseService>();
      for (final id in _selected) {
        await db.deleteFax(id);
      }
      setState(() {
        _selected.clear();
        _selectMode = false;
      });
      if (mounted) {
        context.read<FaxManager>().loadFaxes();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<FaxManager>(
      builder: (context, manager, _) {
        final inbound = manager.recentFaxes
            .where((f) => f.direction == FaxDirection.inbound)
            .toList();

        if (inbound.isEmpty) {
          return const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.inbox, size: 64, color: DeathTheme.textMuted),
                SizedBox(height: 12),
                Text(
                  'NO INCOMING FAXES',
                  style: TextStyle(
                    color: DeathTheme.textPrimary,
                    letterSpacing: 2.0,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Polling for new faxes every 30 seconds',
                  style: TextStyle(
                    color: DeathTheme.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          );
        }

        return Column(
          children: [
            // Action bar when in select mode
            if (_selectMode)
              Container(
                color: DeathTheme.midGrey,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: Row(
                  children: [
                    Text(
                      '${_selected.length} selected',
                      style: const TextStyle(
                        color: DeathTheme.textPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => _selectAll(inbound),
                      child: const Text('SELECT ALL',
                          style: TextStyle(color: DeathTheme.darkRed, fontSize: 12)),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.delete, color: DeathTheme.error),
                      onPressed: _deleteSelected,
                      tooltip: 'Delete selected',
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: DeathTheme.textMuted),
                      onPressed: () => setState(() {
                        _selected.clear();
                        _selectMode = false;
                      }),
                      tooltip: 'Cancel',
                    ),
                  ],
                ),
              ),

            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: inbound.length,
                itemBuilder: (context, index) {
                  final fax = inbound[index];
                  final isSelected = fax.id != null && _selected.contains(fax.id);
                  final hasFile = fax.localFilePath != null && fax.localFilePath!.isNotEmpty;
                  final hasMediaUrl = fax.mediaUrl != null && fax.mediaUrl!.isNotEmpty;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    color: isSelected ? DeathTheme.darkRed.withOpacity(0.2) : null,
                    child: ListTile(
                      leading: _selectMode
                          ? Checkbox(
                              value: isSelected,
                              activeColor: DeathTheme.darkRed,
                              onChanged: (_) {
                                if (fax.id != null) _toggleSelect(fax.id!);
                              },
                            )
                          : const CircleAvatar(
                              backgroundColor: DeathTheme.midGrey,
                              child: Icon(Icons.call_received, color: DeathTheme.deepRed),
                            ),
                      title: Text(
                        fax.contactName ?? fax.fromNumber,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: DeathTheme.textPrimary,
                        ),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${fax.pageCount} page${fax.pageCount != 1 ? "s" : ""} · '
                            '${_formatDate(fax.createdAt)}',
                            style: const TextStyle(
                              fontSize: 11,
                              color: DeathTheme.textSecondary,
                            ),
                          ),
                          if (!hasFile)
                            Text(
                              hasMediaUrl ? 'Tap to download' : 'No media available',
                              style: TextStyle(
                                fontSize: 10,
                                color: hasMediaUrl ? DeathTheme.warning : DeathTheme.textMuted,
                              ),
                            ),
                        ],
                      ),
                      trailing: Icon(
                        hasFile ? Icons.open_in_new : (hasMediaUrl ? Icons.download : Icons.block),
                        color: hasFile ? DeathTheme.darkRed : DeathTheme.textMuted,
                        size: 20,
                      ),
                      onLongPress: () {
                        if (!_selectMode && fax.id != null) {
                          setState(() {
                            _selectMode = true;
                            _selected.add(fax.id!);
                          });
                        }
                      },
                      onTap: () async {
                        if (_selectMode) {
                          if (fax.id != null) _toggleSelect(fax.id!);
                          return;
                        }

                        if (hasFile) {
                          try {
                            await OpenFile.open(fax.localFilePath!);
                          } catch (e) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Could not open file: ${fax.localFilePath}'),
                                  backgroundColor: DeathTheme.error,
                                ),
                              );
                            }
                          }
                        } else if (hasMediaUrl) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Downloading fax...')),
                          );
                          try {
                            await manager.downloadFaxMedia(fax);
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Fax downloaded — tap again to open'),
                                  backgroundColor: DeathTheme.midGrey,
                                ),
                              );
                            }
                          } catch (e) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Download failed: $e'),
                                  backgroundColor: DeathTheme.error,
                                ),
                              );
                            }
                          }
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('No media available for this fax')),
                          );
                        }
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatDate(DateTime dt) {
    return '${dt.month}/${dt.day}/${dt.year} '
        '${dt.hour.toString().padLeft(2, "0")}:'
        '${dt.minute.toString().padLeft(2, "0")}';
  }
}
