import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/death_theme.dart';
import '../models/fax.dart';
import '../services/fax_manager.dart';
import '../services/database_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String _filter = 'all';
  final Set<int> _selected = {};
  bool _selectMode = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FaxManager>().loadFaxes();
    });
  }

  void _toggleSelect(int id) {
    setState(() {
      if (_selected.contains(id)) {
        _selected.remove(id);
        if (_selected.isEmpty) _selectMode = false;
      } else {
        _selected.add(id);
      }
    });
  }

  void _selectAll(List<Fax> faxes) {
    setState(() {
      _selected.addAll(faxes.where((f) => f.id != null).map((f) => f.id!));
    });
  }

  Future<void> _deleteSelected() async {
    if (_selected.isEmpty) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: DeathTheme.darkGrey,
        title: const Text('DELETE FAXES',
            style: TextStyle(color: DeathTheme.darkRed)),
        content: Text('Delete ${_selected.length} fax${_selected.length > 1 ? "es" : ""}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL',
                style: TextStyle(color: DeathTheme.textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: DeathTheme.error),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final db = context.read<DatabaseService>();
      for (final id in _selected) {
        await db.deleteFax(id);
      }
      setState(() {
        _selected.clear();
        _selectMode = false;
      });
      if (mounted) {
        context.read<FaxManager>().loadFaxes();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Filter chips + select actions
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: Row(
            children: [
              if (_selectMode) ...[
                Text(
                  '${_selected.length} selected',
                  style: const TextStyle(
                    color: DeathTheme.textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    final manager = context.read<FaxManager>();
                    var faxes = manager.recentFaxes;
                    if (_filter == 'sent') {
                      faxes = faxes.where((f) => f.direction == FaxDirection.outbound).toList();
                    } else if (_filter == 'received') {
                      faxes = faxes.where((f) => f.direction == FaxDirection.inbound).toList();
                    }
                    _selectAll(faxes);
                  },
                  child: const Text('ALL',
                      style: TextStyle(color: DeathTheme.darkRed, fontSize: 11)),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: DeathTheme.error, size: 20),
                  onPressed: _deleteSelected,
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: DeathTheme.textMuted, size: 20),
                  onPressed: () => setState(() {
                    _selected.clear();
                    _selectMode = false;
                  }),
                ),
              ] else ...[
                _buildFilterChip('ALL', 'all'),
                const SizedBox(width: 8),
                _buildFilterChip('SENT', 'sent'),
                const SizedBox(width: 8),
                _buildFilterChip('RECEIVED', 'received'),
              ],
            ],
          ),
        ),

        Expanded(
          child: Consumer<FaxManager>(
            builder: (context, manager, _) {
              var faxes = manager.recentFaxes;
              if (_filter == 'sent') {
                faxes = faxes.where((f) => f.direction == FaxDirection.outbound).toList();
              } else if (_filter == 'received') {
                faxes = faxes.where((f) => f.direction == FaxDirection.inbound).toList();
              }

              if (faxes.isEmpty) {
                return const Center(
                  child: Text(
                    'No fax history',
                    style: TextStyle(color: DeathTheme.textMuted),
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: faxes.length,
                itemBuilder: (context, index) {
                  final fax = faxes[index];
                  final isInbound = fax.direction == FaxDirection.inbound;
                  final isSelected = fax.id != null && _selected.contains(fax.id);
                  final statusColor = switch (fax.status) {
                    FaxStatus.delivered || FaxStatus.received => DeathTheme.success,
                    FaxStatus.failed => DeathTheme.error,
                    FaxStatus.queued || FaxStatus.sending || FaxStatus.receiving => DeathTheme.warning,
                    FaxStatus.cancelled => DeathTheme.textMuted,
                  };

                  return Card(
                    margin: const EdgeInsets.only(bottom: 6),
                    color: isSelected ? DeathTheme.darkRed.withOpacity(0.2) : null,
                    child: InkWell(
                      onLongPress: () {
                        if (!_selectMode && fax.id != null) {
                          setState(() {
                            _selectMode = true;
                            _selected.add(fax.id!);
                          });
                        }
                      },
                      onTap: _selectMode
                          ? () {
                              if (fax.id != null) _toggleSelect(fax.id!);
                            }
                          : null,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        child: Row(
                          children: [
                            if (_selectMode)
                              Padding(
                                padding: const EdgeInsets.only(right: 12),
                                child: Checkbox(
                                  value: isSelected,
                                  activeColor: DeathTheme.darkRed,
                                  onChanged: (_) {
                                    if (fax.id != null) _toggleSelect(fax.id!);
                                  },
                                ),
                              )
                            else
                              Icon(
                                isInbound ? Icons.call_received : Icons.call_made,
                                size: 18,
                                color: isInbound ? DeathTheme.deepRed : DeathTheme.textSecondary,
                              ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    fax.contactName ?? (isInbound ? fax.fromNumber : fax.toNumber),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      color: DeathTheme.textPrimary,
                                    ),
                                  ),
                                  Text(
                                    _formatDate(fax.createdAt),
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: DeathTheme.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: statusColor.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                fax.statusDisplay,
                                style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  color: statusColor,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildFilterChip(String label, String value) {
    final selected = _filter == value;
    return ChoiceChip(
      label: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          letterSpacing: 1.0,
          color: selected ? DeathTheme.textPrimary : DeathTheme.textMuted,
        ),
      ),
      selected: selected,
      selectedColor: DeathTheme.darkRed,
      backgroundColor: DeathTheme.midGrey,
      onSelected: (_) => setState(() => _filter = value),
    );
  }

  String _formatDate(DateTime dt) {
    return '${dt.month}/${dt.day}/${dt.year} '
        '${dt.hour.toString().padLeft(2, "0")}:'
        '${dt.minute.toString().padLeft(2, "0")}';
  }
}
