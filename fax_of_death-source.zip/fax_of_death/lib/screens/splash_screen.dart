import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme/death_theme.dart';
import '../services/fax_manager.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );
    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );
    _scaleAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(
        parent: _animController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
      ),
    );

    _animController.forward();

    // Delay initialization to after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeAndNavigate();
    });
  }

  Future<void> _initializeAndNavigate() async {
    try {
      final manager = context.read<FaxManager>();
      await manager.initFromPrefs();

      if (manager.isConfigured) {
        manager.startPolling();
        await manager.loadFaxes();
      }
    } catch (e) {
      // Continue to home screen even if init fails
      debugPrint('Init error: $e');
    }

    // Show splash for at least 2.5 seconds
    await Future.delayed(const Duration(milliseconds: 2500));

    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const HomeScreen(),
          transitionsBuilder: (_, animation, __, child) {
            return FadeTransition(opacity: animation, child: child);
          },
          transitionDuration: const Duration(milliseconds: 500),
        ),
      );
    }
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DeathTheme.black,
      body: Center(
        child: AnimatedBuilder(
          animation: _animController,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnim.value,
              child: Transform.scale(
                scale: _scaleAnim.value,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(
                      'assets/images/skull.png',
                      width: 140,
                      height: 140,
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'FAX OF DEATH',
                      style: GoogleFonts.courierPrime(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: DeathTheme.darkRed,
                        letterSpacing: 4.0,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'DEATH\'S HEAD SOFTWARE',
                      style: GoogleFonts.courierPrime(
                        fontSize: 12,
                        color: DeathTheme.textMuted,
                        letterSpacing: 3.0,
                      ),
                    ),
                    const SizedBox(height: 32),
                    const SizedBox(
                      width: 150,
                      child: LinearProgressIndicator(
                        backgroundColor: DeathTheme.midGrey,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          DeathTheme.darkRed,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
