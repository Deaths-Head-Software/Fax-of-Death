import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/death_theme.dart';
import '../services/sinch_service.dart';
import '../services/fax_manager.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isSaving = false;

  final _sinchProjectIdCtrl = TextEditingController();
  final _sinchKeyIdCtrl = TextEditingController();
  final _sinchKeySecretCtrl = TextEditingController();
  final _sinchNumberCtrl = TextEditingController();
  bool _obscureSinchSecret = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _sinchProjectIdCtrl.text = prefs.getString('sinch_project_id') ?? '';
      _sinchKeyIdCtrl.text = prefs.getString('sinch_key_id') ?? '';
      _sinchKeySecretCtrl.text = prefs.getString('sinch_key_secret') ?? '';
      _sinchNumberCtrl.text = prefs.getString('sinch_fax_number') ?? '';
    });
  }

  Future<void> _saveSettings() async {
    setState(() => _isSaving = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
          'sinch_project_id', _sinchProjectIdCtrl.text.trim());
      await prefs.setString('sinch_key_id', _sinchKeyIdCtrl.text.trim());
      await prefs.setString(
          'sinch_key_secret', _sinchKeySecretCtrl.text.trim());
      await prefs.setString('sinch_fax_number', _sinchNumberCtrl.text.trim());

      final config = SinchConfig(
        projectId: _sinchProjectIdCtrl.text.trim(),
        accessKeyId: _sinchKeyIdCtrl.text.trim(),
        accessKeySecret: _sinchKeySecretCtrl.text.trim(),
        faxNumber: _sinchNumberCtrl.text.trim(),
      );
      final sinch = SinchService();
      sinch.configure(config);

      final manager = context.read<FaxManager>();
      manager.setSinch(sinch);
      manager.startPolling();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Settings saved')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  void dispose() {
    _sinchProjectIdCtrl.dispose();
    _sinchKeyIdCtrl.dispose();
    _sinchKeySecretCtrl.dispose();
    _sinchNumberCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SETTINGS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'SINCH API CONFIGURATION',
            style: TextStyle(
              fontSize: 12,
              color: DeathTheme.darkRed,
              letterSpacing: 2.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Get credentials from dashboard.sinch.com',
            style: TextStyle(fontSize: 11, color: DeathTheme.textMuted),
          ),
          const SizedBox(height: 16),

          TextField(
            controller: _sinchProjectIdCtrl,
            decoration: const InputDecoration(
              labelText: 'Project ID',
              prefixIcon:
                  Icon(Icons.folder_outlined, color: DeathTheme.darkRed),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _sinchKeyIdCtrl,
            decoration: const InputDecoration(
              labelText: 'Access Key ID',
              prefixIcon: Icon(Icons.key, color: DeathTheme.darkRed),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _sinchKeySecretCtrl,
            decoration: InputDecoration(
              labelText: 'Access Key Secret',
              prefixIcon:
                  const Icon(Icons.lock_outline, color: DeathTheme.darkRed),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscureSinchSecret
                      ? Icons.visibility_off
                      : Icons.visibility,
                  color: DeathTheme.textMuted,
                  size: 20,
                ),
                onPressed: () =>
                    setState(() => _obscureSinchSecret = !_obscureSinchSecret),
              ),
            ),
            obscureText: _obscureSinchSecret,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _sinchNumberCtrl,
            decoration: const InputDecoration(
              labelText: 'Fax Number (optional)',
              hintText: '+15551234567',
              helperText: 'Your Sinch fax number — leave blank if not yet assigned',
              helperStyle: TextStyle(fontSize: 10, color: DeathTheme.textMuted),
              prefixIcon: Icon(Icons.phone, color: DeathTheme.darkRed),
            ),
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 24),

          // Save button
          SizedBox(
            height: 48,
            child: ElevatedButton.icon(
              onPressed: _isSaving ? null : _saveSettings,
              icon: _isSaving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: DeathTheme.textPrimary,
                      ),
                    )
                  : const Icon(Icons.save),
              label: Text(_isSaving ? 'SAVING...' : 'SAVE SETTINGS'),
            ),
          ),

          const SizedBox(height: 32),
          const Divider(color: DeathTheme.lightGrey),
          const SizedBox(height: 16),

          // Help links
          const Text(
            'HELP',
            style: TextStyle(
              fontSize: 12,
              color: DeathTheme.darkRed,
              letterSpacing: 2.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _HelpTile(
            icon: Icons.open_in_new,
            title: 'Sinch Dashboard',
            subtitle: 'Manage your account and fax numbers',
            onTap: () => launchUrl(
                Uri.parse('https://dashboard.sinch.com'),
                mode: LaunchMode.externalApplication),
          ),
          _HelpTile(
            icon: Icons.description,
            title: 'Sinch Fax API Docs',
            subtitle: 'Developer documentation',
            onTap: () => launchUrl(
                Uri.parse('https://developers.sinch.com/docs/fax'),
                mode: LaunchMode.externalApplication),
          ),

          const SizedBox(height: 32),
          const Divider(color: DeathTheme.lightGrey),
          const SizedBox(height: 16),

          // About
          Center(
            child: Column(
              children: [
                Image.asset(
                  'assets/images/skull.png',
                  width: 48,
                  height: 48,
                ),
                const SizedBox(height: 8),
                const Text(
                  'FAX OF DEATH v1.0.0',
                  style: TextStyle(
                    color: DeathTheme.darkRed,
                    letterSpacing: 2.0,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'DEATH\'S HEAD SOFTWARE',
                  style: TextStyle(
                    color: DeathTheme.textMuted,
                    letterSpacing: 3.0,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

class _HelpTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _HelpTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: DeathTheme.darkRed, size: 20),
        title: Text(title, style: const TextStyle(fontSize: 13)),
        subtitle: Text(subtitle,
            style:
                const TextStyle(fontSize: 10, color: DeathTheme.textMuted)),
        trailing: const Icon(Icons.chevron_right,
            color: DeathTheme.textMuted, size: 18),
        onTap: onTap,
      ),
    );
  }
}
