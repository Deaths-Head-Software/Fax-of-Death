import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/death_theme.dart';
import '../models/contact.dart';
import '../services/database_service.dart';
import 'send_fax_screen.dart';

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});

  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  List<Contact> _contacts = [];
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadContacts();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadContacts([String? search]) async {
    final db = context.read<DatabaseService>();
    final contacts = await db.getContacts(search: search);
    setState(() => _contacts = contacts);
  }

  Future<void> _showContactDialog([Contact? existing]) async {
    final nameCtrl = TextEditingController(text: existing?.name);
    final numberCtrl = TextEditingController(text: existing?.faxNumber);
    final companyCtrl = TextEditingController(text: existing?.company);
    final emailCtrl = TextEditingController(text: existing?.email);
    final notesCtrl = TextEditingController(text: existing?.notes);

    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: DeathTheme.darkGrey,
          title: Text(
            existing == null ? 'ADD CONTACT' : 'EDIT CONTACT',
            style: const TextStyle(
              color: DeathTheme.darkRed,
              letterSpacing: 2.0,
              fontSize: 16,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(labelText: 'Name *'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: numberCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Fax Number *',
                    hintText: '+15551234567',
                  ),
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: companyCtrl,
                  decoration: const InputDecoration(labelText: 'Company'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: emailCtrl,
                  decoration: const InputDecoration(labelText: 'Email'),
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: notesCtrl,
                  decoration: const InputDecoration(labelText: 'Notes'),
                  maxLines: 2,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('CANCEL',
                  style: TextStyle(color: DeathTheme.textMuted)),
            ),
            ElevatedButton(
              onPressed: () async {
                if (nameCtrl.text.isEmpty || numberCtrl.text.isEmpty) return;
                final db = context.read<DatabaseService>();
                final contact = Contact(
                  id: existing?.id,
                  name: nameCtrl.text.trim(),
                  faxNumber: numberCtrl.text.trim(),
                  company: companyCtrl.text.trim().isEmpty
                      ? null
                      : companyCtrl.text.trim(),
                  email: emailCtrl.text.trim().isEmpty
                      ? null
                      : emailCtrl.text.trim(),
                  notes: notesCtrl.text.trim().isEmpty
                      ? null
                      : notesCtrl.text.trim(),
                  createdAt: existing?.createdAt,
                );
                if (existing == null) {
                  await db.insertContact(contact);
                } else {
                  await db.updateContact(contact);
                }
                Navigator.pop(context, true);
              },
              child: Text(existing == null ? 'ADD' : 'SAVE'),
            ),
          ],
        );
      },
    );

    if (result == true) _loadContacts();
  }

  Future<void> _deleteContact(Contact contact) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: DeathTheme.darkGrey,
        title: const Text('DELETE CONTACT',
            style: TextStyle(color: DeathTheme.darkRed)),
        content: Text('Delete ${contact.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL',
                style: TextStyle(color: DeathTheme.textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: DeathTheme.error),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );

    if (confirm == true && contact.id != null) {
      await context.read<DatabaseService>().deleteContact(contact.id!);
      _loadContacts();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    hintText: 'Search contacts...',
                    prefixIcon:
                        Icon(Icons.search, color: DeathTheme.textMuted),
                    isDense: true,
                  ),
                  onChanged: (v) => _loadContacts(v),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                onPressed: () => _showContactDialog(),
                icon: const Icon(Icons.person_add, color: DeathTheme.darkRed),
              ),
            ],
          ),
        ),
        Expanded(
          child: _contacts.isEmpty
              ? const Center(
                  child: Text(
                    'No contacts',
                    style: TextStyle(color: DeathTheme.textMuted),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _contacts.length,
                  itemBuilder: (context, index) {
                    final c = _contacts[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 6),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: DeathTheme.midGrey,
                          child: Text(
                            c.name[0].toUpperCase(),
                            style: const TextStyle(
                              color: DeathTheme.darkRed,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        title: Text(c.name,
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text(
                          '${c.faxNumber}'
                          '${c.company != null ? " · ${c.company}" : ""}',
                          style: const TextStyle(
                            fontSize: 11,
                            color: DeathTheme.textMuted,
                          ),
                        ),
                        trailing: PopupMenuButton<String>(
                          icon: const Icon(Icons.more_vert,
                              color: DeathTheme.textMuted, size: 20),
                          color: DeathTheme.midGrey,
                          onSelected: (action) {
                            switch (action) {
                              case 'fax':
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        SendFaxScreen(preselectedContact: c),
                                  ),
                                );
                              case 'edit':
                                _showContactDialog(c);
                              case 'delete':
                                _deleteContact(c);
                            }
                          },
                          itemBuilder: (_) => [
                            const PopupMenuItem(
                              value: 'fax',
                              child: Row(
                                children: [
                                  Icon(Icons.send,
                                      size: 16, color: DeathTheme.darkRed),
                                  SizedBox(width: 8),
                                  Text('Send Fax'),
                                ],
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'edit',
                              child: Row(
                                children: [
                                  Icon(Icons.edit,
                                      size: 16,
                                      color: DeathTheme.textSecondary),
                                  SizedBox(width: 8),
                                  Text('Edit'),
                                ],
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Row(
                                children: [
                                  Icon(Icons.delete,
                                      size: 16, color: DeathTheme.error),
                                  SizedBox(width: 8),
                                  Text('Delete'),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
