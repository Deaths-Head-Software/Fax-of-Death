import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import '../theme/death_theme.dart';
import '../services/fax_manager.dart';
import '../services/database_service.dart';
import '../models/contact.dart';

class SendFaxScreen extends StatefulWidget {
  final Contact? preselectedContact;
  const SendFaxScreen({super.key, this.preselectedContact});

  @override
  State<SendFaxScreen> createState() => _SendFaxScreenState();
}

class _SendFaxScreenState extends State<SendFaxScreen> {
  final _formKey = GlobalKey<FormState>();
  final _numberController = TextEditingController();
  final _coverPageController = TextEditingController();
  String? _selectedFilePath;
  String? _selectedFileName;
  bool _isSending = false;
  Contact? _selectedContact;

  @override
  void initState() {
    super.initState();
    if (widget.preselectedContact != null) {
      _selectedContact = widget.preselectedContact;
      _numberController.text = widget.preselectedContact!.faxNumber;
    }
  }

  @override
  void dispose() {
    _numberController.dispose();
    _coverPageController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'tif', 'tiff', 'png', 'jpg', 'jpeg'],
    );

    if (result != null && result.files.isNotEmpty) {
      setState(() {
        _selectedFilePath = result.files.first.path;
        _selectedFileName = result.files.first.name;
      });
    }
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final photo = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 90,
    );
    if (photo != null) {
      setState(() {
        _selectedFilePath = photo.path;
        _selectedFileName = photo.name;
      });
    }
  }

  Future<void> _pickContact() async {
    final db = context.read<DatabaseService>();
    final contacts = await db.getContacts();

    if (!mounted) return;
    if (contacts.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No contacts saved yet')),
      );
      return;
    }

    final selected = await showModalBottomSheet<Contact>(
      context: context,
      backgroundColor: DeathTheme.darkGrey,
      builder: (context) {
        return ListView.builder(
          padding: const EdgeInsets.all(8),
          itemCount: contacts.length,
          itemBuilder: (context, index) {
            final c = contacts[index];
            return ListTile(
              title: Text(c.name),
              subtitle: Text(c.faxNumber,
                  style: const TextStyle(color: DeathTheme.textMuted)),
              trailing: c.company != null
                  ? Text(c.company!,
                      style: const TextStyle(
                          fontSize: 11, color: DeathTheme.textMuted))
                  : null,
              onTap: () => Navigator.pop(context, c),
            );
          },
        );
      },
    );

    if (selected != null) {
      setState(() {
        _selectedContact = selected;
        _numberController.text = selected.faxNumber;
      });
    }
  }

  Future<void> _sendFax() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedFilePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select a document to fax')),
      );
      return;
    }

    setState(() => _isSending = true);

    try {
      final manager = context.read<FaxManager>();
      await manager.sendFax(
        toNumber: _numberController.text.trim(),
        filePath: _selectedFilePath!,
        coverPageText: _coverPageController.text.isNotEmpty
            ? _coverPageController.text
            : null,
        contactName: _selectedContact?.name,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Fax queued for sending'),
            backgroundColor: DeathTheme.midGrey,
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: DeathTheme.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SEND FAX'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Recipient
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _numberController,
                    decoration: const InputDecoration(
                      labelText: 'Fax Number',
                      hintText: '+15551234567',
                      prefixIcon: Icon(Icons.phone, color: DeathTheme.darkRed),
                    ),
                    keyboardType: TextInputType.phone,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return 'Enter a fax number';
                      }
                      if (!v.trim().startsWith('+')) {
                        return 'Use E.164 format (+1...)';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _pickContact,
                  icon: const Icon(Icons.contacts, color: DeathTheme.darkRed),
                  tooltip: 'Pick from contacts',
                ),
              ],
            ),
            if (_selectedContact != null) ...[
              const SizedBox(height: 4),
              Text(
                '  ${_selectedContact!.name}'
                '${_selectedContact!.company != null ? " — ${_selectedContact!.company}" : ""}',
                style: const TextStyle(
                    fontSize: 12, color: DeathTheme.textSecondary),
              ),
            ],
            const SizedBox(height: 20),

            // Document selection
            const Text(
              'DOCUMENT',
              style: TextStyle(
                fontSize: 11,
                color: DeathTheme.textMuted,
                letterSpacing: 2.0,
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: InkWell(
                onTap: _pickFile,
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Icon(
                        _selectedFileName != null
                            ? Icons.description
                            : Icons.upload_file,
                        size: 40,
                        color: _selectedFileName != null
                            ? DeathTheme.darkRed
                            : DeathTheme.textMuted,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _selectedFileName ?? 'Tap to select a file',
                        style: TextStyle(
                          color: _selectedFileName != null
                              ? DeathTheme.textPrimary
                              : DeathTheme.textMuted,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'PDF, TIFF, PNG, JPG',
                        style: TextStyle(
                          fontSize: 10,
                          color: DeathTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),

            // Camera button (for mobile)
            if (Platform.isAndroid || Platform.isIOS)
              OutlinedButton.icon(
                onPressed: _takePhoto,
                icon: const Icon(Icons.camera_alt),
                label: const Text('SCAN WITH CAMERA'),
              ),

            const SizedBox(height: 20),

            // Cover page (optional)
            TextFormField(
              controller: _coverPageController,
              decoration: const InputDecoration(
                labelText: 'Cover Page Note (optional)',
                hintText: 'Enter a message for the cover page...',
                prefixIcon: Icon(Icons.note, color: DeathTheme.darkRed),
                alignLabelWithHint: true,
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 32),

            // Send button
            SizedBox(
              height: 50,
              child: ElevatedButton.icon(
                onPressed: _isSending ? null : _sendFax,
                icon: _isSending
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: DeathTheme.textPrimary,
                        ),
                      )
                    : const Icon(Icons.send),
                label: Text(_isSending ? 'SENDING...' : 'SEND FAX'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
