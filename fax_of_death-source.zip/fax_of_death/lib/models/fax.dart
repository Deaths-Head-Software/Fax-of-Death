enum FaxDirection { outbound, inbound }
enum FaxStatus { queued, sending, delivered, receiving, received, failed, cancelled }

class Fax {
  final int? id;
  final String telnyxId;
  final FaxDirection direction;
  FaxStatus status;
  final String fromNumber;
  final String toNumber;
  final int pageCount;
  final String? mediaUrl;
  String? localFilePath;
  final String? coverPageText;
  final DateTime createdAt;
  DateTime? completedAt;
  String? errorMessage;
  final String? contactName;

  Fax({
    this.id,
    required this.telnyxId,
    required this.direction,
    required this.status,
    required this.fromNumber,
    required this.toNumber,
    this.pageCount = 0,
    this.mediaUrl,
    this.localFilePath,
    this.coverPageText,
    required this.createdAt,
    this.completedAt,
    this.errorMessage,
    this.contactName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'telnyx_id': telnyxId,
      'direction': direction.name,
      'status': status.name,
      'from_number': fromNumber,
      'to_number': toNumber,
      'page_count': pageCount,
      'media_url': mediaUrl,
      'local_file_path': localFilePath,
      'cover_page_text': coverPageText,
      'created_at': createdAt.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
      'error_message': errorMessage,
      'contact_name': contactName,
    };
  }

  factory Fax.fromMap(Map<String, dynamic> map) {
    return Fax(
      id: map['id'] as int?,
      telnyxId: map['telnyx_id'] as String,
      direction: FaxDirection.values.firstWhere(
        (e) => e.name == map['direction'],
      ),
      status: FaxStatus.values.firstWhere(
        (e) => e.name == map['status'],
      ),
      fromNumber: map['from_number'] as String,
      toNumber: map['to_number'] as String,
      pageCount: map['page_count'] as int? ?? 0,
      mediaUrl: map['media_url'] as String?,
      localFilePath: map['local_file_path'] as String?,
      coverPageText: map['cover_page_text'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      completedAt: map['completed_at'] != null
          ? DateTime.parse(map['completed_at'] as String)
          : null,
      errorMessage: map['error_message'] as String?,
      contactName: map['contact_name'] as String?,
    );
  }

  String get statusDisplay {
    switch (status) {
      case FaxStatus.queued:
        return 'QUEUED';
      case FaxStatus.sending:
        return 'SENDING...';
      case FaxStatus.delivered:
        return 'DELIVERED';
      case FaxStatus.receiving:
        return 'RECEIVING...';
      case FaxStatus.received:
        return 'RECEIVED';
      case FaxStatus.failed:
        return 'FAILED';
      case FaxStatus.cancelled:
        return 'CANCELLED';
    }
  }

  bool get isComplete =>
      status == FaxStatus.delivered ||
      status == FaxStatus.received ||
      status == FaxStatus.failed ||
      status == FaxStatus.cancelled;
}
