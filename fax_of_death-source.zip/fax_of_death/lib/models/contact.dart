class Contact {
  final int? id;
  String name;
  String faxNumber;
  String? company;
  String? email;
  String? notes;
  final DateTime createdAt;

  Contact({
    this.id,
    required this.name,
    required this.faxNumber,
    this.company,
    this.email,
    this.notes,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'fax_number': faxNumber,
      'company': company,
      'email': email,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Contact.fromMap(Map<String, dynamic> map) {
    return Contact(
      id: map['id'] as int?,
      name: map['name'] as String,
      faxNumber: map['fax_number'] as String,
      company: map['company'] as String?,
      email: map['email'] as String?,
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
