import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:mime/mime.dart' as mime_lookup;

class SinchConfig {
  final String projectId;
  final String accessKeyId;
  final String accessKeySecret;
  final String faxNumber; // E.164 format (optional — leave blank to omit 'from')

  SinchConfig({
    required this.projectId,
    required this.accessKeyId,
    required this.accessKeySecret,
    required this.faxNumber,
  });

  bool get isValid =>
      projectId.isNotEmpty &&
      accessKeyId.isNotEmpty &&
      accessKeySecret.isNotEmpty;

  String get basicAuth =>
      'Basic ${base64Encode(utf8.encode('$accessKeyId:$accessKeySecret'))}';
}

class SinchFaxResponse {
  final bool success;
  final String? faxId;
  final String? status;
  final String? errorMessage;
  final Map<String, dynamic>? data;

  SinchFaxResponse({
    required this.success,
    this.faxId,
    this.status,
    this.errorMessage,
    this.data,
  });
}

class SinchService {
  static const String _baseUrl = 'https://fax.api.sinch.com/v3';
  final Dio _dio = Dio();
  SinchConfig? _config;

  String get providerName => 'Sinch';
  bool get isConfigured => _config?.isValid ?? false;
  String get faxNumber => _config?.faxNumber ?? '';

  String get _projectPath => '/projects/${_config!.projectId}';

  void configure(SinchConfig config) {
    _config = config;
    _dio.options = BaseOptions(
      baseUrl: _baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 60),
    );
  }

  Options get _jsonOptions => Options(
        headers: {
          'Authorization': _config!.basicAuth,
          'Content-Type': 'application/json',
        },
      );

  /// Send a fax using a public content URL.
  Future<SinchFaxResponse> sendFax({
    required String toNumber,
    required String mediaUrl,
    String? from,
  }) async {
    _ensureConfigured();
    try {
      final cleanTo = toNumber.replaceAll(RegExp(r'[\s\-\(\)]'), '');
      final body = <String, dynamic>{
        'to': cleanTo,
        'contentUrl': mediaUrl,
      };
      if (from != null && from.isNotEmpty) {
        body['from'] = from.replaceAll(RegExp(r'[\s\-\(\)]'), '');
      }

      final response = await _dio.post(
        '$_projectPath/faxes',
        data: body,
        options: _jsonOptions,
      );

      final data = response.data as Map<String, dynamic>?;
      return SinchFaxResponse(
        success: true,
        faxId: data?['id']?.toString(),
        status: data?['status']?.toString(),
        data: data,
      );
    } on DioException catch (e) {
      return SinchFaxResponse(
        success: false,
        errorMessage: _parseError(e),
      );
    }
  }

  /// Send a fax with a local file via multipart upload.
  Future<SinchFaxResponse> sendFaxWithFile({
    required String toNumber,
    required String filePath,
    String? from,
  }) async {
    _ensureConfigured();
    try {
      final fileName = p.basename(filePath);
      final mimeType = mime_lookup.lookupMimeType(filePath) ?? 'application/pdf';
      final mimeTypeParts = mimeType.split('/');

      final cleanTo = toNumber.replaceAll(RegExp(r'[\s\-\(\)]'), '');
      final cleanFrom = (from ?? _config!.faxNumber).replaceAll(RegExp(r'[\s\-\(\)]'), '');

      final formData = FormData.fromMap({
        'to': cleanTo,
        if (cleanFrom.isNotEmpty) 'from': cleanFrom,
        'file': await MultipartFile.fromFile(
          filePath,
          filename: fileName,
          contentType: DioMediaType(
            mimeTypeParts[0],
            mimeTypeParts.length > 1 ? mimeTypeParts[1] : 'pdf',
          ),
        ),
      });

      final response = await _dio.post(
        '$_projectPath/faxes',
        data: formData,
        options: Options(
          headers: {
            'Authorization': _config!.basicAuth,
          },
        ),
      );

      final data = response.data as Map<String, dynamic>?;
      return SinchFaxResponse(
        success: true,
        faxId: data?['id']?.toString(),
        status: data?['status']?.toString(),
        data: data,
      );
    } on DioException catch (e) {
      final debugInfo = StringBuffer();
      debugInfo.writeln('URL: $_baseUrl$_projectPath/faxes');
      debugInfo.writeln('Status: ${e.response?.statusCode}');
      debugInfo.writeln('To: $toNumber');
      debugInfo.writeln('From: ${from ?? _config!.faxNumber}');
      debugInfo.writeln('File: $filePath');
      debugInfo.writeln('Response type: ${e.response?.data?.runtimeType}');
      debugInfo.writeln('Response body: ${e.response?.data}');
      debugInfo.writeln('Headers: ${e.response?.headers}');
      final msg = debugInfo.toString();
      debugPrint(msg);
      return SinchFaxResponse(
        success: false,
        errorMessage: msg,
      );
    } catch (e) {
      return SinchFaxResponse(
        success: false,
        errorMessage: 'Unexpected error: $e',
      );
    }
  }

  Future<SinchFaxResponse> getFaxStatus(String faxId) async {
    _ensureConfigured();
    try {
      final response = await _dio.get(
        '$_projectPath/faxes/$faxId',
        options: _jsonOptions,
      );
      final data = response.data as Map<String, dynamic>?;
      return SinchFaxResponse(
        success: true,
        faxId: faxId,
        status: data?['status']?.toString(),
        data: data,
      );
    } on DioException catch (e) {
      return SinchFaxResponse(
        success: false,
        faxId: faxId,
        errorMessage: _parseError(e),
      );
    }
  }

  Future<List<Map<String, dynamic>>> listFaxes({
    String? direction,
    int pageSize = 25,
    int pageNumber = 1,
  }) async {
    _ensureConfigured();
    try {
      final params = <String, dynamic>{
        'pageSize': pageSize,
        'page': pageNumber,
      };
      if (direction != null) {
        params['direction'] = direction;
      }
      final response = await _dio.get(
        '$_projectPath/faxes',
        queryParameters: params,
        options: _jsonOptions,
      );
      final faxes = response.data['faxes'] as List<dynamic>?;
      return faxes?.cast<Map<String, dynamic>>() ?? [];
    } on DioException catch (e) {
      throw Exception('Failed to list faxes: ${_parseError(e)}');
    }
  }

  Future<bool> deleteFax(String faxId) async {
    _ensureConfigured();
    try {
      await _dio.delete('$_projectPath/faxes/$faxId', options: _jsonOptions);
      return true;
    } on DioException {
      return false;
    }
  }

  Future<String?> downloadFaxMedia(String mediaUrl, String faxId) async {
    _ensureConfigured();
    try {
      final dir = await getApplicationDocumentsDirectory();
      final faxDir = Directory(p.join(dir.path, 'fax_of_death', 'received'));
      if (!await faxDir.exists()) await faxDir.create(recursive: true);
      final filePath = p.join(faxDir.path, 'fax_$faxId.pdf');
      await _dio.download(mediaUrl, filePath,
          options: Options(headers: {'Authorization': _config!.basicAuth}));
      return filePath;
    } catch (e) {
      debugPrint('[Sinch] Download from URL failed: $e');
      return null;
    }
  }

  /// Download fax content using the Sinch /file endpoint.
  Future<String?> downloadFaxById(String faxId) async {
    _ensureConfigured();
    try {
      final dir = await getApplicationDocumentsDirectory();
      final faxDir = Directory(p.join(dir.path, 'fax_of_death', 'received'));
      if (!await faxDir.exists()) await faxDir.create(recursive: true);
      final filePath = p.join(faxDir.path, 'fax_$faxId.pdf');

      debugPrint('[Sinch] Downloading fax by ID: $_baseUrl$_projectPath/faxes/$faxId/file');
      await _dio.download(
        '$_projectPath/faxes/$faxId/file',
        filePath,
        options: Options(
          headers: {'Authorization': _config!.basicAuth},
          responseType: ResponseType.bytes,
        ),
      );
      debugPrint('[Sinch] Downloaded fax to: $filePath');
      return filePath;
    } catch (e) {
      debugPrint('[Sinch] Download by ID failed: $e');
      return null;
    }
  }

  /// Poll for inbound faxes. Lists all faxes and filters client-side
  /// since the Sinch direction filter parameter name may vary.
  Future<List<Map<String, dynamic>>> pollInboundFaxes({DateTime? since}) async {
    _ensureConfigured();
    try {
      final params = <String, dynamic>{
        'pageSize': 50,
      };
      debugPrint('[Sinch] Polling faxes: $_baseUrl$_projectPath/faxes params=$params');
      final response = await _dio.get(
        '$_projectPath/faxes',
        queryParameters: params,
        options: _jsonOptions,
      );
      debugPrint('[Sinch] Poll response keys: ${response.data?.keys}');

      // Handle different response shapes
      List<dynamic>? faxList;
      if (response.data is Map) {
        faxList = response.data['faxes'] as List<dynamic>?
            ?? response.data['items'] as List<dynamic>?
            ?? response.data['data'] as List<dynamic>?;
      } else if (response.data is List) {
        faxList = response.data as List<dynamic>;
      }

      if (faxList == null || faxList.isEmpty) {
        debugPrint('[Sinch] No faxes in response. Full response: ${response.data}');
        return [];
      }

      debugPrint('[Sinch] Found ${faxList.length} total faxes');

      // Filter for inbound only, client-side
      final inbound = faxList.where((f) {
        if (f is Map) {
          final dir = f['direction']?.toString().toUpperCase() ?? '';
          return dir == 'INBOUND' || dir == 'RECEIVED';
        }
        return false;
      }).cast<Map<String, dynamic>>().toList();

      debugPrint('[Sinch] ${inbound.length} inbound faxes');

      // Filter by time if needed
      if (since != null) {
        final sinceUtc = since.toUtc();
        return inbound.where((f) {
          final timeStr = f['createTime']?.toString() ?? f['created_at']?.toString();
          if (timeStr == null) return true;
          final time = DateTime.tryParse(timeStr);
          return time == null || time.isAfter(sinceUtc);
        }).toList();
      }

      return inbound;
    } on DioException catch (e) {
      debugPrint('[Sinch] Poll error: ${e.response?.statusCode} ${e.response?.data}');
      return [];
    }
  }

  String normalizeStatus(String providerStatus) {
    switch (providerStatus.toUpperCase()) {
      case 'QUEUED':
      case 'PENDING':
        return 'queued';
      case 'IN_PROGRESS':
      case 'SENDING':
        return 'sending';
      case 'COMPLETED':
      case 'DELIVERED':
        return 'delivered';
      case 'FAILURE':
      case 'FAILED':
        return 'failed';
      case 'CANCELED':
      case 'CANCELLED':
        return 'cancelled';
      default:
        return 'sending';
    }
  }

  void _ensureConfigured() {
    if (!isConfigured) {
      throw Exception(
          'Sinch not configured. Set your project ID and access key in Settings.');
    }
  }

  String _parseError(DioException e) {
    final statusCode = e.response?.statusCode ?? 0;
    final rawData = e.response?.data;

    if (rawData != null) {
      if (rawData is String && rawData.isNotEmpty) {
        return 'HTTP $statusCode: $rawData';
      }
      if (rawData is Map) {
        final data = rawData as Map<String, dynamic>;
        final error = data['error'];
        if (error is Map) {
          final msg = error['message']?.toString() ?? '';
          final code = error['code']?.toString() ?? '';
          final status = error['status']?.toString() ?? '';
          final details = error['details'];
          String detailStr = '';
          if (details is List && details.isNotEmpty) {
            detailStr = details.map((d) => d.toString()).join('; ');
          }
          final parts = <String>[
            'HTTP $statusCode',
            if (status.isNotEmpty) '[$status]',
            if (msg.isNotEmpty) msg,
            if (code.isNotEmpty && code != status) '(code: $code)',
            if (detailStr.isNotEmpty) '\nDetails: $detailStr',
          ];
          return parts.join(' ');
        }
        final msg = data['message']?.toString();
        if (msg != null) return 'HTTP $statusCode: $msg';
        return 'HTTP $statusCode: $data';
      }
      return 'HTTP $statusCode: $rawData';
    }
    return 'HTTP $statusCode: ${e.message ?? "Network error"}';
  }
}
