import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'fax_provider.dart';

class TelnyxConfig {
  final String apiKey;
  final String connectionId;
  final String faxNumber;

  TelnyxConfig({
    required this.apiKey,
    required this.connectionId,
    required this.faxNumber,
  });

  bool get isValid =>
      apiKey.isNotEmpty && connectionId.isNotEmpty && faxNumber.isNotEmpty;
}

class TelnyxProvider implements FaxProvider {
  static const String _baseUrl = 'https://api.telnyx.com/v2';
  final Dio _dio = Dio();
  TelnyxConfig? _config;

  @override
  String get providerName => 'Telnyx';

  @override
  bool get isConfigured => _config?.isValid ?? false;

  @override
  String get faxNumber => _config?.faxNumber ?? '';

  void configure(TelnyxConfig config) {
    _config = config;
    _dio.options = BaseOptions(
      baseUrl: _baseUrl,
      headers: {
        'Authorization': 'Bearer ${config.apiKey}',
        'Content-Type': 'application/json',
      },
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
    );
  }

  @override
  Future<FaxProviderResponse> sendFax({
    required String toNumber,
    required String mediaUrl,
    String? from,
  }) async {
    _ensureConfigured();
    try {
      final response = await _dio.post('/faxes', data: {
        'connection_id': _config!.connectionId,
        'media_url': mediaUrl,
        'to': toNumber,
        'from': from ?? _config!.faxNumber,
      });
      final data = response.data['data'] as Map<String, dynamic>?;
      return FaxProviderResponse(
        success: true,
        faxId: data?['id']?.toString(),
        status: data?['status']?.toString(),
        data: data,
      );
    } on DioException catch (e) {
      return FaxProviderResponse(
        success: false,
        errorMessage: _parseError(e),
      );
    }
  }

  @override
  Future<String?> uploadMedia(String filePath) async {
    _ensureConfigured();
    try {
      final fileName = p.basename(filePath);
      final formData = FormData.fromMap({
        'media': await MultipartFile.fromFile(filePath, filename: fileName),
      });
      final response = await _dio.post('/media', data: formData);
      final data = response.data['data'] as Map<String, dynamic>?;
      return data?['media_url']?.toString() ??
          '$_baseUrl/media/${data?["id"]}';
    } on DioException catch (e) {
      throw Exception('Failed to upload media: ${_parseError(e)}');
    }
  }

  @override
  Future<FaxProviderResponse> getFaxStatus(String faxId) async {
    _ensureConfigured();
    try {
      final response = await _dio.get('/faxes/$faxId');
      final data = response.data['data'] as Map<String, dynamic>?;
      return FaxProviderResponse(
        success: true,
        faxId: faxId,
        status: data?['status']?.toString(),
        data: data,
      );
    } on DioException catch (e) {
      return FaxProviderResponse(
        success: false,
        faxId: faxId,
        errorMessage: _parseError(e),
      );
    }
  }

  @override
  Future<List<Map<String, dynamic>>> listFaxes({
    String? direction,
    int pageSize = 25,
    int pageNumber = 1,
  }) async {
    _ensureConfigured();
    try {
      final params = <String, dynamic>{
        'page[size]': pageSize,
        'page[number]': pageNumber,
      };
      if (direction != null) {
        params['filter[direction]'] = direction;
      }
      final response = await _dio.get('/faxes', queryParameters: params);
      return (response.data['data'] as List<dynamic>?)
              ?.cast<Map<String, dynamic>>() ??
          [];
    } on DioException catch (e) {
      throw Exception('Failed to list faxes: ${_parseError(e)}');
    }
  }

  @override
  Future<bool> deleteFax(String faxId) async {
    _ensureConfigured();
    try {
      await _dio.delete('/faxes/$faxId');
      return true;
    } on DioException {
      return false;
    }
  }

  @override
  Future<String?> downloadFaxMedia(String mediaUrl, String faxId) async {
    _ensureConfigured();
    try {
      final dir = await getApplicationDocumentsDirectory();
      final faxDir = Directory(p.join(dir.path, 'fax_of_death', 'received'));
      if (!await faxDir.exists()) await faxDir.create(recursive: true);
      final filePath = p.join(faxDir.path, 'fax_$faxId.pdf');
      await _dio.download(mediaUrl, filePath,
          options: Options(
              headers: {'Authorization': 'Bearer ${_config!.apiKey}'}));
      return filePath;
    } catch (_) {
      return null;
    }
  }

  @override
  Future<List<Map<String, dynamic>>> pollInboundFaxes({DateTime? since}) async {
    _ensureConfigured();
    try {
      final params = <String, dynamic>{
        'filter[direction]': 'inbound',
        'page[size]': 25,
      };
      if (since != null) {
        params['filter[created_at][gte]'] = since.toUtc().toIso8601String();
      }
      final response = await _dio.get('/faxes', queryParameters: params);
      return (response.data['data'] as List<dynamic>?)
              ?.cast<Map<String, dynamic>>() ??
          [];
    } on DioException {
      return [];
    }
  }

  @override
  String normalizeStatus(String providerStatus) {
    switch (providerStatus) {
      case 'queued':
        return 'queued';
      case 'media.processed':
      case 'initiated':
      case 'sending':
        return 'sending';
      case 'delivered':
        return 'delivered';
      case 'received':
        return 'received';
      case 'failed':
        return 'failed';
      case 'cancelled':
        return 'cancelled';
      default:
        return 'sending';
    }
  }

  void _ensureConfigured() {
    if (!isConfigured) {
      throw Exception(
          'Telnyx not configured. Set your API key, connection ID, '
          'and fax number in Settings.');
    }
  }

  String _parseError(DioException e) {
    if (e.response?.data != null) {
      try {
        final errors = e.response!.data['errors'] as List<dynamic>?;
        if (errors != null && errors.isNotEmpty) {
          final first = errors.first as Map<String, dynamic>;
          return first['detail']?.toString() ??
              first['title']?.toString() ??
              'Unknown error';
        }
      } catch (_) {}
    }
    switch (e.response?.statusCode) {
      case 401:
      case 403:
        return 'Invalid API key or insufficient permissions';
      case 404:
        return 'Resource not found';
      case 422:
        return 'Invalid parameters — check fax number format (E.164)';
      case 429:
        return 'Rate limit exceeded — try again shortly';
      default:
        return e.message ?? 'Network error';
    }
  }
}
