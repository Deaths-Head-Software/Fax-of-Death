/// Abstract interface for fax API providers.
/// Both Telnyx and Sinch/Phaxio implement this.
abstract class FaxProvider {
  String get providerName;
  bool get isConfigured;
  String get faxNumber;

  /// Send a fax. Returns a provider-specific fax ID on success.
  Future<FaxProviderResponse> sendFax({
    required String toNumber,
    required String mediaUrl,
    String? from,
  });

  /// Upload a local file and return a URL the provider can use to send it.
  Future<String?> uploadMedia(String filePath);

  /// Get the current status of a fax by its provider ID.
  Future<FaxProviderResponse> getFaxStatus(String faxId);

  /// List faxes from the provider, optionally filtered by direction.
  Future<List<Map<String, dynamic>>> listFaxes({
    String? direction,
    int pageSize = 25,
    int pageNumber = 1,
  });

  /// Delete a fax record on the provider side.
  Future<bool> deleteFax(String faxId);

  /// Download a received fax's media to local storage. Returns local path.
  Future<String?> downloadFaxMedia(String mediaUrl, String faxId);

  /// Poll for new inbound faxes since [since].
  Future<List<Map<String, dynamic>>> pollInboundFaxes({DateTime? since});

  /// Map a provider-specific status string to our normalized status.
  String normalizeStatus(String providerStatus);
}

class FaxProviderResponse {
  final bool success;
  final String? faxId;
  final String? status;
  final String? errorMessage;
  final Map<String, dynamic>? data;

  FaxProviderResponse({
    required this.success,
    this.faxId,
    this.status,
    this.errorMessage,
    this.data,
  });
}

/// Supported fax API providers.
enum FaxProviderType {
  telnyx,
  sinch;

  String get displayName {
    switch (this) {
      case FaxProviderType.telnyx:
        return 'Telnyx';
      case FaxProviderType.sinch:
        return 'Sinch (Phaxio)';
    }
  }

  String get description {
    switch (this) {
      case FaxProviderType.telnyx:
        return '\$0.007/page + SIP usage + ~\$1-2/mo per number';
      case FaxProviderType.sinch:
        return '\$0.07/page, no monthly fees, no number rental';
    }
  }
}
