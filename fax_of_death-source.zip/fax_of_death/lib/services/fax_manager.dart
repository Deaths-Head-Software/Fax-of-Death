import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/fax.dart';
import 'sinch_service.dart';
import 'database_service.dart';

/// Central manager that ties the Sinch fax API to local persistence
/// and runs the polling loop for inbound faxes.
class FaxManager extends ChangeNotifier {
  SinchService? _sinch;
  final DatabaseService _db;

  Timer? _pollTimer;
  DateTime? _lastPollTime;
  bool _isPolling = false;

  List<Fax> _recentFaxes = [];
  List<Fax> get recentFaxes => _recentFaxes;

  int _unreadCount = 0;
  int get unreadCount => _unreadCount;

  bool get isConfigured => _sinch?.isConfigured ?? false;
  String get faxNumber => _sinch?.faxNumber ?? '';

  FaxManager({required DatabaseService databaseService}) : _db = databaseService;

  /// Initialize from saved settings.
  Future<void> initFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final config = SinchConfig(
      projectId: prefs.getString('sinch_project_id') ?? '',
      accessKeyId: prefs.getString('sinch_key_id') ?? '',
      accessKeySecret: prefs.getString('sinch_key_secret') ?? '',
      faxNumber: prefs.getString('sinch_fax_number') ?? '',
    );
    if (config.isValid) {
      final sinch = SinchService();
      sinch.configure(config);
      _sinch = sinch;
      notifyListeners();
    }
  }

  void setSinch(SinchService sinch) {
    _sinch = sinch;
    notifyListeners();
  }

  /// Start the inbound fax polling loop.
  void startPolling({Duration interval = const Duration(seconds: 30)}) {
    stopPolling();
    if (!isConfigured) return;
    // On first poll, only look back 1 hour to avoid re-downloading old faxes
    _lastPollTime ??= DateTime.now().subtract(const Duration(hours: 1));
    _pollTimer = Timer.periodic(interval, (_) => _pollForNewFaxes());
    _pollForNewFaxes();
  }

  void stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  /// Send a fax. [filePath] is the local PDF/image to fax.
  Future<Fax?> sendFax({
    required String toNumber,
    required String filePath,
    String? coverPageText,
    String? contactName,
  }) async {
    if (_sinch == null || !_sinch!.isConfigured) {
      throw Exception('Sinch not configured. Set your credentials in Settings.');
    }

    try {
      final response = await _sinch!.sendFaxWithFile(
        toNumber: toNumber,
        filePath: filePath,
      );

      if (!response.success) {
        throw Exception(response.errorMessage ?? 'Failed to send fax');
      }

      final fax = Fax(
        telnyxId: response.faxId ?? '',
        direction: FaxDirection.outbound,
        status: FaxStatus.queued,
        fromNumber: _sinch!.faxNumber,
        toNumber: toNumber,
        localFilePath: filePath,
        coverPageText: coverPageText,
        contactName: contactName,
        createdAt: DateTime.now(),
      );

      await _db.insertFax(fax);
      await _refreshRecentFaxes();

      if (response.faxId != null) {
        _trackFaxStatus(response.faxId!);
      }

      return fax;
    } catch (e) {
      rethrow;
    }
  }

  /// Track an outbound fax until it reaches a terminal state.
  /// Checks every 15 seconds, times out after 5 minutes.
  void _trackFaxStatus(String faxId) {
    int attempts = 0;
    const maxAttempts = 20; // 5 minutes at 15-second intervals
    String? lastStatus;

    Timer.periodic(const Duration(seconds: 15), (timer) async {
      attempts++;
      if (_sinch == null || attempts > maxAttempts) {
        debugPrint('[FaxManager] Status tracking timed out for $faxId');
        await _db.updateFaxStatus(faxId, FaxStatus.delivered);
        await _refreshRecentFaxes();
        timer.cancel();
        return;
      }
      try {
        final response = await _sinch!.getFaxStatus(faxId);

        if (response.success && response.status != null) {
          // Only log when status changes
          if (response.status != lastStatus) {
            debugPrint('[FaxManager] Fax $faxId: ${response.status}');
            lastStatus = response.status;
          }

          final normalized = _sinch!.normalizeStatus(response.status!);
          final newStatus = FaxStatus.values.firstWhere(
            (s) => s.name == normalized,
            orElse: () => FaxStatus.sending,
          );

          await _db.updateFaxStatus(faxId, newStatus,
              errorMessage: newStatus == FaxStatus.failed
                  ? (response.data?['failureReason']?.toString() ??
                      response.data?['failure_reason']?.toString() ??
                      response.data?['error']?['message']?.toString())
                  : null);
          await _refreshRecentFaxes();

          if (newStatus == FaxStatus.delivered ||
              newStatus == FaxStatus.received ||
              newStatus == FaxStatus.failed ||
              newStatus == FaxStatus.cancelled) {
            debugPrint('[FaxManager] Fax $faxId complete: $newStatus');
            timer.cancel();
          }
        }
      } catch (e) {
        debugPrint('[FaxManager] Status check error: $e');
      }
    });
  }

  /// Poll for new inbound faxes.
  Future<void> _pollForNewFaxes() async {
    if (_isPolling || _sinch == null || !_sinch!.isConfigured) return;
    _isPolling = true;

    try {
      // First poll: don't filter by time so we catch any existing inbound faxes
      final faxes = await _sinch!.pollInboundFaxes(since: _lastPollTime);
      _lastPollTime = DateTime.now();

      debugPrint('[FaxManager] Polled for inbound faxes: found ${faxes.length}');

      for (final faxData in faxes) {
        debugPrint('[FaxManager] Inbound fax data: $faxData');
        final faxId = faxData['id']?.toString() ?? '';
        if (faxId.isEmpty) continue;

        final existing = await _db.getFaxByTelnyxId(faxId);
        if (existing != null) {
          debugPrint('[FaxManager] Fax $faxId already in database, skipping');
          continue;
        }

        final mediaUrl = faxData['media_url']?.toString() ??
            faxData['contentUrl']?.toString();
        String? localPath;

        // Try downloading via the /file endpoint (works for inbound faxes)
        localPath = await _sinch!.downloadFaxById(faxId);

        // Fallback to media URL if /file didn't work
        if (localPath == null && mediaUrl != null) {
          localPath = await _sinch!.downloadFaxMedia(mediaUrl, faxId);
        }

        debugPrint('[FaxManager] Downloaded fax media to: $localPath');

        final fax = Fax(
          telnyxId: faxId,
          direction: FaxDirection.inbound,
          status: FaxStatus.received,
          fromNumber: faxData['from']?.toString() ?? 'Unknown',
          toNumber: faxData['to']?.toString() ?? _sinch!.faxNumber,
          pageCount: faxData['page_count'] as int? ??
              faxData['pageCount'] as int? ??
              faxData['numberOfPages'] as int? ??
              0,
          mediaUrl: mediaUrl,
          localFilePath: localPath,
          createdAt: faxData['createTime'] != null
              ? DateTime.tryParse(faxData['createTime'].toString()) ??
                  DateTime.now()
              : faxData['created_at'] != null
                  ? DateTime.tryParse(faxData['created_at'].toString()) ??
                      DateTime.now()
                  : DateTime.now(),
          completedAt: DateTime.now(),
        );

        await _db.insertFax(fax);
        _unreadCount++;
        debugPrint('[FaxManager] Saved inbound fax from ${fax.fromNumber}');
      }

      if (faxes.isNotEmpty) await _refreshRecentFaxes();
    } catch (e) {
      debugPrint('[FaxManager] Poll error: $e');
    } finally {
      _isPolling = false;
    }
  }

  /// Download media for an inbound fax that wasn't downloaded during polling.
  Future<void> downloadFaxMedia(Fax fax) async {
    if (_sinch == null) throw Exception('Sinch not configured');

    // Try the /file endpoint first (works for inbound faxes)
    String? localPath = await _sinch!.downloadFaxById(fax.telnyxId);

    // Fallback to media URL
    if (localPath == null && fax.mediaUrl != null) {
      localPath = await _sinch!.downloadFaxMedia(fax.mediaUrl!, fax.telnyxId);
    }

    if (localPath != null) {
      fax.localFilePath = localPath;
      await _db.updateFax(fax);
      await _refreshRecentFaxes();
      debugPrint('[FaxManager] Downloaded fax ${fax.telnyxId} to $localPath');
    } else {
      throw Exception('Download failed — fax content may not be available yet');
    }
  }

  Future<void> _refreshRecentFaxes() async {
    _recentFaxes = await _db.getFaxes(limit: 50);
    notifyListeners();
  }

  Future<void> loadFaxes({FaxDirection? direction}) async {
    _recentFaxes = await _db.getFaxes(direction: direction, limit: 50);
    notifyListeners();
  }

  void clearUnread() {
    _unreadCount = 0;
    notifyListeners();
  }

  @override
  void dispose() {
    stopPolling();
    super.dispose();
  }
}
