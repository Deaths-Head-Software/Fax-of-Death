import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/fax.dart';
import '../models/contact.dart';

class DatabaseService {
  static Database? _database;

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'fax_of_death.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createTables,
    );
  }

  Future<void> _createTables(Database db, int version) async {
    await db.execute('''
      CREATE TABLE faxes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telnyx_id TEXT NOT NULL,
        direction TEXT NOT NULL,
        status TEXT NOT NULL,
        from_number TEXT NOT NULL,
        to_number TEXT NOT NULL,
        page_count INTEGER DEFAULT 0,
        media_url TEXT,
        local_file_path TEXT,
        cover_page_text TEXT,
        created_at TEXT NOT NULL,
        completed_at TEXT,
        error_message TEXT,
        contact_name TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        fax_number TEXT NOT NULL,
        company TEXT,
        email TEXT,
        notes TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_faxes_created ON faxes(created_at DESC)
    ''');
    await db.execute('''
      CREATE INDEX idx_faxes_status ON faxes(status)
    ''');
    await db.execute('''
      CREATE INDEX idx_faxes_telnyx_id ON faxes(telnyx_id)
    ''');
  }

  // ── Fax CRUD ──

  Future<int> insertFax(Fax fax) async {
    final db = await database;
    return await db.insert('faxes', fax.toMap()..remove('id'));
  }

  Future<void> updateFax(Fax fax) async {
    final db = await database;
    await db.update(
      'faxes',
      fax.toMap(),
      where: 'id = ?',
      whereArgs: [fax.id],
    );
  }

  Future<void> updateFaxStatus(String telnyxId, FaxStatus status,
      {String? errorMessage}) async {
    final db = await database;
    final updates = <String, dynamic>{
      'status': status.name,
    };
    if (status == FaxStatus.delivered || status == FaxStatus.received) {
      updates['completed_at'] = DateTime.now().toIso8601String();
    }
    if (errorMessage != null) {
      updates['error_message'] = errorMessage;
    }
    await db.update(
      'faxes',
      updates,
      where: 'telnyx_id = ?',
      whereArgs: [telnyxId],
    );
  }

  Future<List<Fax>> getFaxes({
    FaxDirection? direction,
    int limit = 50,
    int offset = 0,
  }) async {
    final db = await database;
    String? where;
    List<dynamic>? whereArgs;
    if (direction != null) {
      where = 'direction = ?';
      whereArgs = [direction.name];
    }
    final maps = await db.query(
      'faxes',
      where: where,
      whereArgs: whereArgs,
      orderBy: 'created_at DESC',
      limit: limit,
      offset: offset,
    );
    return maps.map((m) => Fax.fromMap(m)).toList();
  }

  Future<Fax?> getFaxByTelnyxId(String telnyxId) async {
    final db = await database;
    final maps = await db.query(
      'faxes',
      where: 'telnyx_id = ?',
      whereArgs: [telnyxId],
      limit: 1,
    );
    if (maps.isEmpty) return null;
    return Fax.fromMap(maps.first);
  }

  Future<void> deleteFax(int id) async {
    final db = await database;
    await db.delete('faxes', where: 'id = ?', whereArgs: [id]);
  }

  // ── Contact CRUD ──

  Future<int> insertContact(Contact contact) async {
    final db = await database;
    return await db.insert('contacts', contact.toMap()..remove('id'));
  }

  Future<void> updateContact(Contact contact) async {
    final db = await database;
    await db.update(
      'contacts',
      contact.toMap(),
      where: 'id = ?',
      whereArgs: [contact.id],
    );
  }

  Future<List<Contact>> getContacts({String? search}) async {
    final db = await database;
    if (search != null && search.isNotEmpty) {
      return (await db.query(
        'contacts',
        where: 'name LIKE ? OR fax_number LIKE ? OR company LIKE ?',
        whereArgs: ['%$search%', '%$search%', '%$search%'],
        orderBy: 'name ASC',
      ))
          .map((m) => Contact.fromMap(m))
          .toList();
    }
    return (await db.query('contacts', orderBy: 'name ASC'))
        .map((m) => Contact.fromMap(m))
        .toList();
  }

  Future<void> deleteContact(int id) async {
    final db = await database;
    await db.delete('contacts', where: 'id = ?', whereArgs: [id]);
  }
}
